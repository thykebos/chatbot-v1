﻿namespace chatbotv1
{
    partial class akademikislemler
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btncikis = new System.Windows.Forms.Panel();
            this.btnmin = new System.Windows.Forms.Panel();
            this.btngeri = new System.Windows.Forms.Panel();
            this.btn_sinavtarihi = new System.Windows.Forms.Button();
            this.btn_devamsizlik = new System.Windows.Forms.Button();
            this.btn_not = new System.Windows.Forms.Button();
            this.btn_dersprogrami = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btncikis
            // 
            this.btncikis.BackColor = System.Drawing.Color.Transparent;
            this.btncikis.Location = new System.Drawing.Point(497, 13);
            this.btncikis.Name = "btncikis";
            this.btncikis.Size = new System.Drawing.Size(21, 20);
            this.btncikis.TabIndex = 4;
            this.btncikis.Click += new System.EventHandler(this.btncikis_Click);
            // 
            // btnmin
            // 
            this.btnmin.BackColor = System.Drawing.Color.Transparent;
            this.btnmin.Location = new System.Drawing.Point(467, 13);
            this.btnmin.Name = "btnmin";
            this.btnmin.Size = new System.Drawing.Size(21, 20);
            this.btnmin.TabIndex = 3;
            this.btnmin.Click += new System.EventHandler(this.btnmin_Click);
            this.btnmin.Paint += new System.Windows.Forms.PaintEventHandler(this.btnmin_Paint);
            // 
            // btngeri
            // 
            this.btngeri.BackColor = System.Drawing.Color.Transparent;
            this.btngeri.Location = new System.Drawing.Point(436, 13);
            this.btngeri.Name = "btngeri";
            this.btngeri.Size = new System.Drawing.Size(21, 20);
            this.btngeri.TabIndex = 4;
            this.btngeri.Click += new System.EventHandler(this.btngeri_Click);
            // 
            // btn_sinavtarihi
            // 
            this.btn_sinavtarihi.BackColor = System.Drawing.Color.Black;
            this.btn_sinavtarihi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_sinavtarihi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_sinavtarihi.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_sinavtarihi.Location = new System.Drawing.Point(174, 429);
            this.btn_sinavtarihi.Name = "btn_sinavtarihi";
            this.btn_sinavtarihi.Size = new System.Drawing.Size(176, 83);
            this.btn_sinavtarihi.TabIndex = 17;
            this.btn_sinavtarihi.Text = "Sınav Tarihi Ve Yerleri";
            this.btn_sinavtarihi.UseVisualStyleBackColor = false;
            this.btn_sinavtarihi.Click += new System.EventHandler(this.btn_sinavtarihi_Click);
            // 
            // btn_devamsizlik
            // 
            this.btn_devamsizlik.BackColor = System.Drawing.Color.Black;
            this.btn_devamsizlik.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_devamsizlik.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_devamsizlik.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_devamsizlik.Location = new System.Drawing.Point(174, 235);
            this.btn_devamsizlik.Name = "btn_devamsizlik";
            this.btn_devamsizlik.Size = new System.Drawing.Size(176, 83);
            this.btn_devamsizlik.TabIndex = 16;
            this.btn_devamsizlik.Text = "Devamsızlık Bilgisi";
            this.btn_devamsizlik.UseVisualStyleBackColor = false;
            this.btn_devamsizlik.Click += new System.EventHandler(this.btn_devamsizlik_Click);
            // 
            // btn_not
            // 
            this.btn_not.BackColor = System.Drawing.Color.Black;
            this.btn_not.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_not.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_not.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_not.Location = new System.Drawing.Point(174, 332);
            this.btn_not.Name = "btn_not";
            this.btn_not.Size = new System.Drawing.Size(176, 83);
            this.btn_not.TabIndex = 15;
            this.btn_not.Text = "Not Görüntüleme";
            this.btn_not.UseVisualStyleBackColor = false;
            this.btn_not.Click += new System.EventHandler(this.btn_not_Click);
            // 
            // btn_dersprogrami
            // 
            this.btn_dersprogrami.BackColor = System.Drawing.Color.Black;
            this.btn_dersprogrami.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_dersprogrami.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_dersprogrami.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_dersprogrami.Location = new System.Drawing.Point(174, 139);
            this.btn_dersprogrami.Name = "btn_dersprogrami";
            this.btn_dersprogrami.Size = new System.Drawing.Size(176, 83);
            this.btn_dersprogrami.TabIndex = 14;
            this.btn_dersprogrami.Text = "Ders Programı";
            this.btn_dersprogrami.UseVisualStyleBackColor = false;
            this.btn_dersprogrami.Click += new System.EventHandler(this.btn_dersprogrami_Click);
            // 
            // akademikislemler
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::chatbotv1.Properties.Resources.akademikislemler;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(530, 560);
            this.Controls.Add(this.btn_sinavtarihi);
            this.Controls.Add(this.btn_devamsizlik);
            this.Controls.Add(this.btn_not);
            this.Controls.Add(this.btn_dersprogrami);
            this.Controls.Add(this.btngeri);
            this.Controls.Add(this.btncikis);
            this.Controls.Add(this.btnmin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "akademikislemler";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "akademikislemler";
            this.Load += new System.EventHandler(this.akademikislemler_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel btncikis;
        private System.Windows.Forms.Panel btnmin;
        private System.Windows.Forms.Panel btngeri;
        private System.Windows.Forms.Button btn_sinavtarihi;
        private System.Windows.Forms.Button btn_devamsizlik;
        private System.Windows.Forms.Button btn_not;
        private System.Windows.Forms.Button btn_dersprogrami;
    }
}