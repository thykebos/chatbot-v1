﻿namespace chatbotv1
{
    partial class anasayfa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnmin = new System.Windows.Forms.Panel();
            this.btncikis = new System.Windows.Forms.Panel();
            this.chatbot = new System.Windows.Forms.TextBox();
            this.btn_erisim = new System.Windows.Forms.Button();
            this.btn_iletisim = new System.Windows.Forms.Button();
            this.btn_belgeler = new System.Windows.Forms.Button();
            this.btn_odeme = new System.Windows.Forms.Button();
            this.btn_kayit = new System.Windows.Forms.Button();
            this.btn_akademi = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnmin
            // 
            this.btnmin.BackColor = System.Drawing.Color.Transparent;
            this.btnmin.Location = new System.Drawing.Point(466, 13);
            this.btnmin.Name = "btnmin";
            this.btnmin.Size = new System.Drawing.Size(21, 20);
            this.btnmin.TabIndex = 1;
            this.btnmin.Click += new System.EventHandler(this.btnmin_Click);
            // 
            // btncikis
            // 
            this.btncikis.BackColor = System.Drawing.Color.Transparent;
            this.btncikis.Location = new System.Drawing.Point(497, 13);
            this.btncikis.Name = "btncikis";
            this.btncikis.Size = new System.Drawing.Size(21, 20);
            this.btncikis.TabIndex = 2;
            this.btncikis.Click += new System.EventHandler(this.btncikis_Click);
            // 
            // chatbot
            // 
            this.chatbot.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.chatbot.Location = new System.Drawing.Point(80, 134);
            this.chatbot.Name = "chatbot";
            this.chatbot.Size = new System.Drawing.Size(367, 29);
            this.chatbot.TabIndex = 3;
            this.chatbot.KeyDown += new System.Windows.Forms.KeyEventHandler(this.chatbot_KeyDown);
            // 
            // btn_erisim
            // 
            this.btn_erisim.BackColor = System.Drawing.Color.Black;
            this.btn_erisim.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_erisim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_erisim.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_erisim.Location = new System.Drawing.Point(271, 312);
            this.btn_erisim.Name = "btn_erisim";
            this.btn_erisim.Size = new System.Drawing.Size(176, 83);
            this.btn_erisim.TabIndex = 13;
            this.btn_erisim.Text = "Hızlı Erişim";
            this.btn_erisim.UseVisualStyleBackColor = false;
            this.btn_erisim.Click += new System.EventHandler(this.btn_erisim_Click);
            // 
            // btn_iletisim
            // 
            this.btn_iletisim.BackColor = System.Drawing.Color.Black;
            this.btn_iletisim.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_iletisim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_iletisim.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_iletisim.Location = new System.Drawing.Point(271, 408);
            this.btn_iletisim.Name = "btn_iletisim";
            this.btn_iletisim.Size = new System.Drawing.Size(176, 83);
            this.btn_iletisim.TabIndex = 12;
            this.btn_iletisim.Text = "İletişim";
            this.btn_iletisim.UseVisualStyleBackColor = false;
            this.btn_iletisim.Click += new System.EventHandler(this.btn_iletisim_Click);
            // 
            // btn_belgeler
            // 
            this.btn_belgeler.BackColor = System.Drawing.Color.Black;
            this.btn_belgeler.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_belgeler.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_belgeler.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_belgeler.Location = new System.Drawing.Point(80, 312);
            this.btn_belgeler.Name = "btn_belgeler";
            this.btn_belgeler.Size = new System.Drawing.Size(176, 83);
            this.btn_belgeler.TabIndex = 11;
            this.btn_belgeler.Text = "Belgeler";
            this.btn_belgeler.UseVisualStyleBackColor = false;
            this.btn_belgeler.Click += new System.EventHandler(this.btn_belgeler_Click);
            // 
            // btn_odeme
            // 
            this.btn_odeme.BackColor = System.Drawing.Color.Black;
            this.btn_odeme.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_odeme.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_odeme.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_odeme.Location = new System.Drawing.Point(80, 408);
            this.btn_odeme.Name = "btn_odeme";
            this.btn_odeme.Size = new System.Drawing.Size(176, 83);
            this.btn_odeme.TabIndex = 10;
            this.btn_odeme.Text = "Ödeme İşlemleri";
            this.btn_odeme.UseVisualStyleBackColor = false;
            this.btn_odeme.Click += new System.EventHandler(this.btn_odeme_Click);
            // 
            // btn_kayit
            // 
            this.btn_kayit.BackColor = System.Drawing.Color.Black;
            this.btn_kayit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_kayit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_kayit.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_kayit.Location = new System.Drawing.Point(271, 216);
            this.btn_kayit.Name = "btn_kayit";
            this.btn_kayit.Size = new System.Drawing.Size(176, 83);
            this.btn_kayit.TabIndex = 9;
            this.btn_kayit.Text = "Kayıt İşlemleri";
            this.btn_kayit.UseVisualStyleBackColor = false;
            this.btn_kayit.Click += new System.EventHandler(this.btn_kayit_Click);
            // 
            // btn_akademi
            // 
            this.btn_akademi.BackColor = System.Drawing.Color.Black;
            this.btn_akademi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_akademi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_akademi.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_akademi.Location = new System.Drawing.Point(80, 216);
            this.btn_akademi.Name = "btn_akademi";
            this.btn_akademi.Size = new System.Drawing.Size(176, 83);
            this.btn_akademi.TabIndex = 8;
            this.btn_akademi.Text = "Akademik İşlemler";
            this.btn_akademi.UseVisualStyleBackColor = false;
            this.btn_akademi.Click += new System.EventHandler(this.btn_akademi_Click);
            // 
            // anasayfa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::chatbotv1.Properties.Resources.anasayfa2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(530, 560);
            this.Controls.Add(this.btn_erisim);
            this.Controls.Add(this.btn_iletisim);
            this.Controls.Add(this.btn_belgeler);
            this.Controls.Add(this.btn_odeme);
            this.Controls.Add(this.btn_kayit);
            this.Controls.Add(this.btn_akademi);
            this.Controls.Add(this.chatbot);
            this.Controls.Add(this.btncikis);
            this.Controls.Add(this.btnmin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "anasayfa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "anasayfa";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel btnmin;
        private System.Windows.Forms.Panel btncikis;
        private System.Windows.Forms.TextBox chatbot;
        private System.Windows.Forms.Button btn_erisim;
        private System.Windows.Forms.Button btn_iletisim;
        private System.Windows.Forms.Button btn_belgeler;
        private System.Windows.Forms.Button btn_odeme;
        private System.Windows.Forms.Button btn_kayit;
        private System.Windows.Forms.Button btn_akademi;
    }
}