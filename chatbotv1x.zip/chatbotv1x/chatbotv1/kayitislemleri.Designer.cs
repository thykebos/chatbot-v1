﻿namespace chatbotv1
{
    partial class kayitislemleri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btngeri = new System.Windows.Forms.Panel();
            this.btncikis = new System.Windows.Forms.Panel();
            this.btnmin = new System.Windows.Forms.Panel();
            this.btn_kayityenile = new System.Windows.Forms.Button();
            this.btn_kayitsorgula = new System.Windows.Forms.Button();
            this.btn_derskayit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btngeri
            // 
            this.btngeri.BackColor = System.Drawing.Color.Transparent;
            this.btngeri.Location = new System.Drawing.Point(436, 13);
            this.btngeri.Name = "btngeri";
            this.btngeri.Size = new System.Drawing.Size(21, 20);
            this.btngeri.TabIndex = 7;
            this.btngeri.Click += new System.EventHandler(this.btngeri_Click);
            // 
            // btncikis
            // 
            this.btncikis.BackColor = System.Drawing.Color.Transparent;
            this.btncikis.Location = new System.Drawing.Point(497, 13);
            this.btncikis.Name = "btncikis";
            this.btncikis.Size = new System.Drawing.Size(21, 20);
            this.btncikis.TabIndex = 6;
            this.btncikis.Click += new System.EventHandler(this.btncikis_Click);
            // 
            // btnmin
            // 
            this.btnmin.BackColor = System.Drawing.Color.Transparent;
            this.btnmin.Location = new System.Drawing.Point(467, 13);
            this.btnmin.Name = "btnmin";
            this.btnmin.Size = new System.Drawing.Size(21, 20);
            this.btnmin.TabIndex = 5;
            this.btnmin.Click += new System.EventHandler(this.btnmin_Click);
            // 
            // btn_kayityenile
            // 
            this.btn_kayityenile.BackColor = System.Drawing.Color.Black;
            this.btn_kayityenile.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_kayityenile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_kayityenile.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_kayityenile.Location = new System.Drawing.Point(178, 271);
            this.btn_kayityenile.Name = "btn_kayityenile";
            this.btn_kayityenile.Size = new System.Drawing.Size(176, 83);
            this.btn_kayityenile.TabIndex = 20;
            this.btn_kayityenile.Text = "Kayıt Yenileme";
            this.btn_kayityenile.UseVisualStyleBackColor = false;
            this.btn_kayityenile.Click += new System.EventHandler(this.btn_kayityenile_Click);
            // 
            // btn_kayitsorgula
            // 
            this.btn_kayitsorgula.BackColor = System.Drawing.Color.Black;
            this.btn_kayitsorgula.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_kayitsorgula.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_kayitsorgula.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_kayitsorgula.Location = new System.Drawing.Point(178, 368);
            this.btn_kayitsorgula.Name = "btn_kayitsorgula";
            this.btn_kayitsorgula.Size = new System.Drawing.Size(176, 83);
            this.btn_kayitsorgula.TabIndex = 19;
            this.btn_kayitsorgula.Text = "Kayıt Durumu Sorgula";
            this.btn_kayitsorgula.UseVisualStyleBackColor = false;
            this.btn_kayitsorgula.Click += new System.EventHandler(this.btn_kayitsorgula_Click);
            // 
            // btn_derskayit
            // 
            this.btn_derskayit.BackColor = System.Drawing.Color.Black;
            this.btn_derskayit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_derskayit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_derskayit.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_derskayit.Location = new System.Drawing.Point(178, 175);
            this.btn_derskayit.Name = "btn_derskayit";
            this.btn_derskayit.Size = new System.Drawing.Size(176, 83);
            this.btn_derskayit.TabIndex = 18;
            this.btn_derskayit.Text = "Ders Kayıt";
            this.btn_derskayit.UseVisualStyleBackColor = false;
            this.btn_derskayit.Click += new System.EventHandler(this.btn_derskayit_Click);
            // 
            // kayitislemleri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::chatbotv1.Properties.Resources.kayitislemleri;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(530, 560);
            this.Controls.Add(this.btn_kayityenile);
            this.Controls.Add(this.btn_kayitsorgula);
            this.Controls.Add(this.btn_derskayit);
            this.Controls.Add(this.btngeri);
            this.Controls.Add(this.btncikis);
            this.Controls.Add(this.btnmin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "kayitislemleri";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "kayitislemleri";
            this.Load += new System.EventHandler(this.kayitislemleri_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel btngeri;
        private System.Windows.Forms.Panel btncikis;
        private System.Windows.Forms.Panel btnmin;
        private System.Windows.Forms.Button btn_kayityenile;
        private System.Windows.Forms.Button btn_kayitsorgula;
        private System.Windows.Forms.Button btn_derskayit;
    }
}